import { ButtonLink, PageIntro, SectionHeading } from "@/components/SiteLayout";

const stages = [
  { number: "01", title: "The idea", body: "You have the premise, the notes, or the voice — but not yet the shape. We help you find the book inside the idea." },
  { number: "02", title: "The manuscript", body: "You are deep in drafting or revision. We give you a clear editorial lens and a plan you can actually use." },
  { number: "03", title: "The release", body: "The book is nearly ready. We help connect the final details: format, positioning, route, and launch." },
  { number: "04", title: "The next chapter", body: "You are building a body of work. We become a trusted editorial partner for your longer author journey." },
];

const paths = [
  { title: "I’m writing my first book", body: "Start with clarity, not pressure. We’ll help you understand the shape of the project and the next doable move." },
  { title: "I have a manuscript that needs direction", body: "Get an honest read on the manuscript’s strengths, gaps, and revision priorities before you spend more time polishing." },
  { title: "I’m ready to publish", body: "Move from finished draft to prepared book with the right editorial, design, format, and publishing decisions in place." },
  { title: "I want a more intentional author platform", body: "Build visibility around your work with a marketing approach that feels like an extension of your voice — not a performance." },
];

export default function ForAuthors() {
  return <>
    <PageIntro eyebrow="For authors" title={<>Your book is a journey. You don’t have to take it <em>alone.</em></>} body="Niel Publishing Ltd supports writers at the point where they are — from first idea to finished book, from launch day to the work that follows." >
      <ButtonLink href="/contact" variant="light">Tell us where you are</ButtonLink>
    </PageIntro>
    <section className="stage-section"><div className="container"><SectionHeading eyebrow="Meet the moment you’re in" title="Support that meets you at the right stage." body="There is no single correct way to become an author. There is only the next honest step for your book." /><div className="stage-grid">{stages.map((stage) => <article className="stage-card" key={stage.number}><span className="stage-card__number">{stage.number}</span><h3>{stage.title}</h3><p>{stage.body}</p></article>)}</div></div></section>
    <section className="author-path"><div className="container author-path__grid"><div className="author-path__copy"><SectionHeading eyebrow="Start here" title={<>A clearer path through the <em>work.</em></>} body="Choose the sentence that sounds most like today. We’ll take it from there." /></div><div className="path-list">{paths.map((path, index) => <article className="path-list__item" key={path.title}><span>0{index + 1}</span><div><h3>{path.title}</h3><p>{path.body}</p></div></article>)}</div></div></section>
    <section className="section section--ink"><div className="container split-cta"><div className="split-cta__copy"><p className="eyebrow">A conversation, not a pitch</p><h2>Bring the question you keep circling.</h2><p>We’ll listen carefully, tell you what we see, and recommend a thoughtful way forward — even if that means starting small.</p></div><div className="split-cta__actions"><ButtonLink href="/contact" variant="light">Start a conversation</ButtonLink></div></div></section>
  </>;
}
