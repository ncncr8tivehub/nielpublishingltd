import { ArrowUpRight } from "lucide-react";
import { Link } from "wouter";
import { ButtonLink, Eyebrow, SectionHeading } from "@/components/SiteLayout";
import { BrandPositioning } from "@/components/BrandPositioning";

const highlights = [
  { number: "01", title: "Shape the story", body: "Editorial thinking that protects the heart of your book while making every chapter work harder." },
  { number: "02", title: "Polish the page", body: "Careful language, considered design, and the finishing detail that helps a book feel ready." },
  { number: "03", title: "Move it forward", body: "Practical publishing and launch guidance for authors who want a clear next step." },
];

export default function Home() {
  return <>
    <section className="hero"><div className="container hero__inner"><div className="hero__copy"><Eyebrow>Publishing support for authors</Eyebrow><h1>Make the book in your head <em>real.</em></h1><p className="hero__lede">Niel Publishing Ltd helps startup and established authors turn good ideas into stronger manuscripts, thoughtful books, and confident next chapters.</p><div className="hero__actions"><ButtonLink href="/contact">Talk about your book</ButtonLink><ButtonLink href="/services" variant="text">Explore services</ButtonLink></div><div className="hero__stamp">Editorial<br />care<br /><span>✦</span><br />practical<br />guidance</div></div><div className="hero__visual"><div className="hero__book-line" /><div className="hero__visual-copy"><span>For the work that matters</span><p>Good books begin with a clear <em>point of view.</em></p></div></div></div></section>
    <section className="section section--white"><div className="container"><div className="home-intro__grid"><SectionHeading eyebrow="The Niel approach" title={<>A publishing partner who sees the <em>whole</em> book.</>} /><p>From first outline to final proof, we bring editorial clarity, creative care, and practical momentum to the parts of publishing that can feel overwhelming alone.</p></div><div className="capability-grid">{highlights.map((item) => <article className="capability-card" key={item.number}><span className="capability-card__number">{item.number}</span><h3>{item.title}</h3><p>{item.body}</p><Link className="capability-card__link" href="/services">See how we help <ArrowUpRight size={14} /></Link></article>)}</div></div></section>
    <section className="pullquote"><div className="container pullquote__inner"><Eyebrow>Our point of view</Eyebrow><blockquote>“Your voice is the <em>starting point.</em> Our job is to help it travel further.”</blockquote></div></section>
    <BrandPositioning />
    <section className="section section--ink"><div className="container split-cta"><div className="split-cta__copy"><Eyebrow>One good next step</Eyebrow><h2>Bring us the messy middle.</h2><p>You don’t need a perfect manuscript or a polished plan. Start with where you are, and we’ll help you see what the book needs next.</p><div className="split-cta__actions"><ButtonLink href="/contact" variant="light">Book a discovery call</ButtonLink><ButtonLink href="/for-authors" variant="text">I’m an author</ButtonLink></div></div><div className="split-cta__note"><strong>↗</strong><p>Whether you’re building your first book or returning to a long-held project, thoughtful support can change the way you move through it.</p></div></div></section>
  </>;
}
