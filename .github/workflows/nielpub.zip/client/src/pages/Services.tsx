import { ButtonLink, PageIntro } from "@/components/SiteLayout";
import { BrandPositioning } from "@/components/BrandPositioning";

const services = [
  { number: "01", title: "Manuscript assessment", body: "A clear editorial read on what is working, what is holding the manuscript back, and the most useful path through revision.", tags: ["Editorial report", "Big-picture feedback"] },
  { number: "02", title: "Developmental editing", body: "Structure, pacing, character, argument, and through-line — the deeper work that helps a book become itself.", tags: ["Structure", "Story & voice"] },
  { number: "03", title: "Copyediting & proofreading", body: "Precise, respectful line-level care that makes the writing cleaner, more consistent, and easier to trust.", tags: ["Clarity", "Consistency"] },
  { number: "04", title: "Book formatting", body: "Professional interior formatting for print and digital editions, with attention to rhythm, readability, and the reader’s experience.", tags: ["Print layout", "Ebook-ready"] },
  { number: "05", title: "Cover & visual direction", body: "A strong visual point of entry — from cover thinking and creative briefs to cohesive author-world direction.", tags: ["Creative direction", "Cover brief"] },
  { number: "06", title: "Publishing guidance", body: "Practical support with route-to-market decisions, production stages, metadata, timelines, and the questions that arrive in between.", tags: ["Independent", "Traditional"] },
  { number: "07", title: "Author platform & marketing", body: "A grounded approach to building visibility around your work without losing the voice that made you write it.", tags: ["Positioning", "Content planning"] },
  { number: "08", title: "Launch planning", body: "A thoughtful, usable plan for release — connecting your book, your audience, and the moments that create momentum.", tags: ["Launch map", "Reader journey"] },
  { number: "09", title: "Ongoing editorial support", body: "A steady editorial sounding board for authors with multiple projects, a growing platform, or a long publishing horizon.", tags: ["Retainers", "Long-term care"] },
];

export default function Services() {
  return <>
    <PageIntro eyebrow="What we do" title={<>The right care for every <em>stage</em> of the book.</>} body="Publishing is a sequence of decisions. We help you make the important ones with clarity, craft, and a practical eye on what comes next." />
    <BrandPositioning />
    <section className="services-list"><div className="container">{services.map((service) => <article className="service-row" key={service.number}><span className="service-row__number">{service.number}</span><h3>{service.title}</h3><div className="service-row__copy"><p>{service.body}</p><div className="service-row__tags">{service.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></div></article>)}</div></section>
    <section className="section section--deep"><div className="container split-cta"><div className="split-cta__copy"><p className="eyebrow">Not sure where to begin?</p><h2>Let’s find the useful question.</h2><p>Tell us where your project is today. We’ll help you identify the kind of support that will make the biggest difference.</p><div className="split-cta__actions"><ButtonLink href="/contact" variant="dark">Ask about your project</ButtonLink></div></div><div className="split-cta__note" style={{ borderColor: "rgba(23,50,77,0.2)", color: "var(--ink-soft)" }}><strong style={{ color: "var(--gold)" }}>✦</strong><p>Good publishing support is not about adding more to your plate. It is about making the next step easier to see.</p></div></div></section>
  </>;
}
