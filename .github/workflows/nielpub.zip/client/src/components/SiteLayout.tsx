import { useEffect, useState, type ReactNode } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { Link, useLocation } from "wouter";

const navItems = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "For authors", href: "/for-authors" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export const socialLinks = [
  { label: "Instagram", handle: "@nielpublishingltd_", href: "https://www.instagram.com/nielpublishingltd_/" },
  { label: "Facebook", handle: "Nathaniel Anthony", href: "https://www.facebook.com/nielpublishingltd" },
  { label: "X", handle: "@niel_publishing", href: "https://x.com/niel_publishing" },
];

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className={`brand-mark ${compact ? "brand-mark--compact" : ""}`} aria-label="Niel Publishing Ltd home">
      <img src="/manus-storage/NielPublishingLtdLOGO_04cf2133.png" alt="" className="brand-mark__logo" />
      <span className="brand-mark__type"><span>Niel Publishing</span><small>Ltd</small></span>
    </Link>
  );
}

export function ButtonLink({ href, children, variant = "dark", className = "" }: { href: string; children: ReactNode; variant?: "dark" | "light" | "text"; className?: string }) {
  return <Link href={href} className={`button-link button-link--${variant} ${className}`}><span>{children}</span><ArrowUpRight size={16} strokeWidth={1.8} /></Link>;
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="eyebrow"><span className="eyebrow__line" />{children}</p>;
}

export function PageIntro({ eyebrow, title, body, children, tone = "cream" }: { eyebrow: string; title: ReactNode; body: string; children?: ReactNode; tone?: "cream" | "ink" }) {
  return <section className={`page-intro page-intro--${tone}`}><div className="container page-intro__inner"><div><Eyebrow>{eyebrow}</Eyebrow><h1>{title}</h1></div><div className="page-intro__aside"><p>{body}</p>{children}</div></div></section>;
}

export function SectionHeading({ eyebrow, title, body, align = "left" }: { eyebrow: string; title: ReactNode; body?: string; align?: "left" | "right" }) {
  return <div className={`section-heading section-heading--${align}`}><Eyebrow>{eyebrow}</Eyebrow><h2>{title}</h2>{body && <p>{body}</p>}</div>;
}

export default function SiteLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => { setOpen(false); window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior }); }, [location]);

  return <div className="site-shell">
    <header className="site-header"><div className="container site-header__inner"><BrandMark />
      <nav className={`site-nav ${open ? "site-nav--open" : ""}`} aria-label="Primary navigation"><div className="site-nav__links">{navItems.map((item) => <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}>{item.label}</Link>)}</div><ButtonLink href="/contact" variant="dark" className="site-nav__cta">Start a conversation</ButtonLink></nav>
      <button type="button" className="menu-toggle" aria-label={open ? "Close navigation" : "Open navigation"} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X size={22} /> : <Menu size={22} />}</button>
    </div></header>
    <main>{children}</main>
    <footer className="site-footer"><div className="container"><div className="site-footer__top"><div><BrandMark compact /><p className="site-footer__claim">Clearer books.<br />Stronger author journeys.</p></div><div className="site-footer__links"><div><p className="footer-label">Explore</p>{navItems.slice(1).map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}</div><div><p className="footer-label">Find us</p>{socialLinks.map((social) => <a key={social.label} href={social.href} target="_blank" rel="noreferrer">{social.label}<ArrowUpRight size={13} /></a>)}</div></div></div><div className="site-footer__bottom"><span>© {new Date().getFullYear()} Niel Publishing Ltd</span><span>Publishing support for the work that matters to you.</span></div></div></footer>
  </div>;
}
