import { ArrowUpRight, BookOpen, Compass, Feather, Megaphone, PenLine, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { Eyebrow, SectionHeading } from "@/components/SiteLayout";

const skills = [
  { icon: PenLine, title: "Editorial direction", body: "A sharp eye for structure, story, voice, and the changes that make a manuscript stronger." },
  { icon: BookOpen, title: "Manuscript care", body: "Developmental editing, copyediting, proofreading, and thoughtful feedback at every stage." },
  { icon: Sparkles, title: "Book presentation", body: "Formatting and visual direction that help your book feel as considered as the words inside it." },
  { icon: Compass, title: "Publishing guidance", body: "Clear next steps across routes to market, production, metadata, timelines, and launch." },
  { icon: Megaphone, title: "Author visibility", body: "Practical platform, content, and marketing thinking that still sounds like you." },
  { icon: Feather, title: "A steady partner", body: "On-demand editorial support when you need perspective, momentum, or a second pair of eyes." },
];

export function BrandPositioning() {
  return (
    <section className="brand-positioning section section--deep">
      <div className="container">
        <div className="brand-positioning__intro">
          <SectionHeading eyebrow="The Niel Publishing vision" title={<>More authors making the books they were <em>meant</em> to make.</>} body="We imagine a publishing landscape where strong ideas are met with clear guidance, careful craft, and support that respects the author behind the work." />
          <div className="brand-positioning__mission"><Eyebrow>Our mission</Eyebrow><p>To help startup and established authors develop, publish, and grow meaningful books through accessible editorial expertise, practical publishing support, and long-term care.</p></div>
        </div>
        <div className="brand-positioning__rule" />
        <div className="brand-positioning__skills-head"><div><Eyebrow>On-demand skills</Eyebrow><h2>Call on the right expertise<br /><em>when you need it.</em></h2></div><p>Choose one focused service or bring us in as your trusted publishing partner across the whole journey.</p></div>
        <div className="on-demand-grid">{skills.map(({ icon: Icon, title, body }) => <article className="on-demand-card" key={title}><Icon className="on-demand-card__icon" size={21} strokeWidth={1.5} /><h3>{title}</h3><p>{body}</p></article>)}</div>
        <Link href="/services" className="brand-positioning__link">See all publishing services <ArrowUpRight size={15} /></Link>
      </div>
    </section>
  );
}
